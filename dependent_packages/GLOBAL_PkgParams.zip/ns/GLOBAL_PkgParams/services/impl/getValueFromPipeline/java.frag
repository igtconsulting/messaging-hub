<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getValueFromPipeline</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNCg0KU3Ry
aW5nIHZhclBhdGggPSAoU3RyaW5nKSBJRGF0YVV0aWwuZ2V0KHBpcGVsaW5lQ3Vyc29yLCAidmFy
UGF0aCIpOw0KDQp0cnl7DQpJRGF0YVV0aWwucHV0KHBpcGVsaW5lQ3Vyc29yLCAicmVzdWx0Iiwg
cmVjdXJzZUdldChwaXBlbGluZSx2YXJQYXRoKSk7DQp9DQpjYXRjaChFeGNlcHRpb24gZSl7DQoJ
dGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRpb24oZS5nZXRNZXNzYWdlKCkpOw0KfQ0KDQpwaXBlbGlu
ZUN1cnNvci5kZXN0cm95KCk7</value>
</Values>
