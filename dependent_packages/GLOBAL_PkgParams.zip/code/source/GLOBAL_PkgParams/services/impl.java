package GLOBAL_PkgParams.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.Files;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardCopyOption;
import com.wm.app.b2b.server.PackageManager;
import com.wm.app.b2b.server.ServerAPI;
// --- <<IS-END-IMPORTS>> ---

public final class impl

{
	// ---( internal utility methods )---

	final static impl _instance = new impl();

	static impl _newInstance() { return new impl(); }

	static impl _cast(Object o) { return (impl)o; }

	// ---( server methods )---




	public static final void getConfigFromPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConfigFromPackage)>> ---
		// @sigtype java 3.5
		// [i] field:0:required pkgName
		// [i] field:0:required env
		// [o] field:0:required result
		IDataCursor pipelineCursor = pipeline.getCursor();
		String packageName = IDataUtil.getString(pipelineCursor, "pkgName");
		String env = IDataUtil.getString(pipelineCursor, "env");
		pipelineCursor.destroy();
		String jsonString;
		
		if (packageName == null || packageName.equalsIgnoreCase("undefined")) {
			throw new ServiceException("Invalid pkgName value.");
		}
		
		File configDir = new File(PackageManager.getPackageDir()+"/"+packageName+"/config");
		
		if (!configDir.exists()) {
			throw new ServiceException("Package not found.");
		}
		
		String configFileName = "params" + env + ".json"; 
		File configFile = new File(configDir, configFileName);
		
		if (!configFile.exists()) {
			throw new ServiceException("Config not found.");
		}
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader(configFile));
			StringBuilder stringBuilder = new StringBuilder();
			String line = null;
			String ls = System.getProperty("line.separator");
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
			// delete the last new line separator
			stringBuilder.deleteCharAt(stringBuilder.length() - 1);
			reader.close();
		
			jsonString = stringBuilder.toString();
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		
		
		IDataUtil.put(pipelineCursor, "result", jsonString);
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getValueFromPipeline (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getValueFromPipeline)>> ---
		// @sigtype java 3.5
		// [i] field:0:required varPath
		// [o] field:0:required result
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String varPath = (String) IDataUtil.get(pipelineCursor, "varPath");
		
		try{
		IDataUtil.put(pipelineCursor, "result", recurseGet(pipeline,varPath));
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
		
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void writeConfigToPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeConfigToPackage)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configString
		// [i] field:0:required pkgName
		// [i] field:0:required env
		// [o] field:0:required result
		IDataCursor pipelineCursor = pipeline.getCursor();
		String configString = IDataUtil.getString(pipelineCursor, "configString");
		String packageName = IDataUtil.getString(pipelineCursor, "pkgName");
		String env = IDataUtil.getString(pipelineCursor, "env");
		pipelineCursor.destroy();
		
		
		if (packageName == null) {
			throw new ServiceException("pkgName canno't be null");
		}
		File configDir = new File(PackageManager.getPackageDir()+"/"+packageName+"/config");
		if (!configDir.exists()) {
			throw new ServiceException("Config dir " + configDir.getAbsolutePath() + " doesn't exist.");
		}
		
		String configFileName = "params" + env + ".json"; 
		String bakConfigFileName = "params" + env + ".json.bak"; 
		File configFile = new File(configDir, configFileName);
		File bakConfigFile = new File(configDir, bakConfigFileName);
		
		
		
		try {
			
			if(configFile.exists()){
				Files.copy(configFile, bakConfigFile, true);
			}
				
		    FileOutputStream outputStream = new FileOutputStream(configFile);
		    byte[] strToBytes = configString.getBytes();
		    outputStream.write(strToBytes);
		
		    outputStream.close();
		
		} catch( Exception e ) {
			throw new ServiceException(e.getMessage());
		}
		
		IDataUtil.put(pipelineCursor, "result", "OK");
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static Object recurseGet(IData pipeline, String varPath) throws ServiceException{
		IDataCursor pipelineCursor = pipeline.getCursor();
		try{
			int slashIdx = varPath.indexOf("/");
			if (slashIdx == 0) {
				varPath = varPath.substring(1);
				slashIdx = varPath.indexOf("/");
			}
			
			if (slashIdx != -1){
				String node = varPath.substring(0,slashIdx);
				String remainer = varPath.substring(slashIdx+1);
				IData childPipeline = (IData) IDataUtil.get(pipelineCursor, node);
				if (childPipeline == null) return null;
				return recurseGet(childPipeline,remainer);
			}
			else{
				return IDataUtil.get(pipelineCursor, varPath);
			}
			
		}
		catch(Exception e){
		throw new ServiceException(e.getMessage());
		}
	}
	// --- <<IS-END-SHARED>> ---
}

