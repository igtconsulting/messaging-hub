package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.is.dynamicvariables.DynamicVariablesEncryptionException;
import com.softwareag.is.dynamicvariables.DynamicVariablesEncryptor;
// --- <<IS-END-IMPORTS>> ---

public final class crypt

{
	// ---( internal utility methods )---

	final static crypt _instance = new crypt();

	static crypt _newInstance() { return new crypt(); }

	static crypt _cast(Object o) { return (crypt)o; }

	// ---( server methods )---




	public static final void encryptString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encryptString)>> ---
		// @sigtype java 3.5
		IDataCursor cursor = pipeline.getCursor();
		try {
			IDataUtil.put(cursor, "test", DynamicVariablesEncryptor.instance().encryptData("Jozko"));
		} catch (DynamicVariablesEncryptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		//DynamicVariablesEncryptor.instance().decryptData(null)
			
		// --- <<IS-END>> ---

                
	}
}

