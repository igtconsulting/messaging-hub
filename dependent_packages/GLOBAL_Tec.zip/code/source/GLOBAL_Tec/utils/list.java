package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.lang.reflect.Array;
// --- <<IS-END-IMPORTS>> ---

public final class list

{
	// ---( internal utility methods )---

	final static list _instance = new list();

	static list _newInstance() { return new list(); }

	static list _cast(Object o) { return (list)o; }

	// ---( server methods )---




	public static final void split (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(split)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required list
		// [i] field:0:required batchSize
		// [o] record:1:required batchList
		// [o] - record:1:required documents
		IDataCursor pipelineCursor = pipeline.getCursor();
		final IData[] list = IDataUtil.getIDataArray( pipelineCursor, "list" );
		final int batchSize = IDataUtil.getInt( pipelineCursor, "batchSize" , -1);
		
		if(batchSize != -1 && list != null) {
			final int batchListSize = list.length % batchSize == 0 ? list.length / batchSize : list.length / batchSize + 1;
			final IData[] batchList = new IData[batchListSize];
			int batchCount = 0;
			int unprocessedCount = list.length;
			IData batch = IDataFactory.create();
			IDataCursor batchCursor = batch.getCursor();
			IData[] documents = new IData[batchSize];
			for(int i = 0; i < list.length; i++) {
				if(i % batchSize == 0) {
					int size = unprocessedCount / batchSize >= 1 ? batchSize :  unprocessedCount % batchSize;
					batch = IDataFactory.create();
					batchList[batchCount] = batch;
					batchCount += 1; 
					batchCursor = batch.getCursor();
					documents = new IData[size];
					IDataUtil.put(batchCursor, "documents" ,documents);
				}
				documents[i % batchSize] = list[i];
				unprocessedCount--;
			}
			IDataUtil.put( pipelineCursor, "batchList", batchList );
		} else {
			throw new IllegalArgumentException("Parameter batchSize must be integer and parameter list must not be null.");
		}
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

