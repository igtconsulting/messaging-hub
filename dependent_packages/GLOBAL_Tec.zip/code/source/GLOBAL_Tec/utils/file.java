package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.net.FileNameMap;
import java.util.Arrays;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipOutputStream;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.core.ZipFile;
// --- <<IS-END-IMPORTS>> ---

public final class file

{
	// ---( internal utility methods )---

	final static file _instance = new file();

	static file _newInstance() { return new file(); }

	static file _cast(Object o) { return (file)o; }

	// ---( server methods )---




	public static final void renameFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(renameFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required oldFileName
		// [i] field:0:required newFileName
		// [o] field:0:required renameStatus
		IDataCursor cursor = pipeline.getCursor();
		
		String oldFileName = null;
		String input = IDataUtil.getString( cursor, "newFileName" );
		
		if (cursor.first("oldFileName"))
		{
			oldFileName = (String) cursor.getValue();
		}
		else
		{
			throw new ServiceException("Input parameter \'oldFileName\' was not found.");
		}
		
		cursor.destroy();
		
		
		File oldFile = new File(oldFileName);
		File newFile = new File(input);
		
		
		boolean b = oldFile.renameTo(newFile);
		
		if (!b)
		     { 		
			throw new ServiceException("File was not renamed.");
		 }
		
		cursor = pipeline.getCursor();
		cursor.last();
		cursor.insertAfter("renameStatus", "" + b);
		cursor.destroy();
			 
		// --- <<IS-END>> ---

                
	}



	public static final void setResponseBytes (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setResponseBytes)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required bytes
		// [i] field:0:required encoding
		// [i] field:0:required contentType
		// [i] field:0:required remoteFilename
		IDataCursor idc = pipeline.getCursor(); 
		byte[] bytes = (byte [])IDataUtil.get(idc, "bytes"); 
		String encoding = IDataUtil.getString(idc, "encoding"); 
		String contentType = IDataUtil.getString(idc, "contentType"); 
		String remoteFilename = IDataUtil.getString(idc, "remoteFilename"); 
		idc.destroy(); 
		
		com.wm.net.HttpHeader httpheader = Service.getHttpResponseHeader(); 
		
		if(httpheader != null) 
		{ 
		if(contentType!=null && !contentType.equals("")) 
			httpheader.addField("content-type", contentType); 
		if(encoding!=null && !encoding.equals("")) 
			httpheader.addField("encoding",encoding); 
		if(remoteFilename!=null && !remoteFilename.equals("")) 
			httpheader.addField("content-disposition", "inline;filename= \""+ remoteFilename+ "\""); 
		} 
		Service.setResponse(bytes); 
		// --- <<IS-END>> ---

                
	}



	public static final void zipFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(zipFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required zipContentFileName
		// [i] field:0:required zipPassword
		// [i] object:0:required fileBytes
		// [o] object:0:required zipBytes
		ByteArrayOutputStream baos = null;
		ZipOutputStream zout = null;
		 
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		byte[] fileBytes = (byte[]) IDataUtil.get(pipelineCursor, "fileBytes");
		
		String zipContentFileName = (String) IDataUtil.get(pipelineCursor, "zipContentFileName");
		String zipPassword = (String) IDataUtil.get(pipelineCursor, "zipPassword");
		
		  
		try {
					baos = new ByteArrayOutputStream();
				    zout = new ZipOutputStream(baos);
					
				    ZipParameters zipParameters = new ZipParameters();
				    zipParameters.setEncryptFiles(true);
				    zipParameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD); //Zip4jConstants.ENC_METHOD_AES
				    //zipParameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256); //AES_STRENGTH_256
				    zipParameters.setCompressionMethod(Zip4jConstants.COMP_STORE);
				    //zipParameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
				    
				    zipParameters.setSourceExternalStream(true);
				    zipParameters.setFileNameInZip(zipContentFileName);
				    zipParameters.setPassword(zipPassword.toCharArray());
				   
				    zout.putNextEntry(null,zipParameters);
				    zout.write(fileBytes);
				    zout.closeEntry();
				    zout.finish();
		      
				    IDataUtil.put(pipelineCursor, "zipBytes", baos.toByteArray());
		    	
				} catch (IOException e) {
					throw new ServiceException(e.getMessage());
				} catch (ZipException e) {
					throw new ServiceException(e.getMessage());
		} finally {
		    if (baos != null) {
		        try {
		            baos.close();
		        } catch (IOException e) {
		        	throw new ServiceException(e.getMessage());
		        }
		    }
		    if (zout != null) {
		        try {
		            zout.close();
		        } catch (IOException e) {
		        	throw new ServiceException(e.getMessage());
		        }
		    }
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static Hashtable<String,String> mimeExtention = new Hashtable<String,String>();
	
	public static String getContentType(String filename) {
		String suffix = filename.substring(filename.lastIndexOf(".")+1).toUpperCase();
		String contentType = null;
	
		if (mimeExtention.containsKey(suffix)) {
			contentType = mimeExtention.get(suffix);
		} else {
			FileNameMap fileNameMap = URLConnection.getFileNameMap();
			contentType = fileNameMap.getContentTypeFor(filename);
		}
		if (contentType == null) contentType = "application/octet-stream";
	
		return contentType;
	}
	// --- <<IS-END-SHARED>> ---
}

