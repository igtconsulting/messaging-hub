package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.wm.util.Debug;
import java.io.*;
import java.util.*;
import java.lang.System;
import com.wm.app.b2b.server.*;
import com.wm.util.Table;
import java.text.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class flow

{
	// ---( internal utility methods )---

	final static flow _instance = new flow();

	static flow _newInstance() { return new flow(); }

	static flow _cast(Object o) { return (flow)o; }

	// ---( server methods )---




	public static final void getUserInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUserInfo)>> ---
		// @sigtype java 3.5
		// [o] record:0:required userInfo
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "userInfo", com.wm.app.b2b.server.Service.getUser().getAsData());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void pipelineAsDocument (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(pipelineAsDocument)>> ---
		// @sigtype java 3.5
		// [o] record:0:required pipelineDoc
	IData pipelineCopy = null;
	IDataCursor cursor = pipeline.getCursor();
	
	try {
		IDataUtil.put(cursor, "pipelineDoc", IDataUtil.deepClone(pipeline));
	} catch (Exception ex) {
		throw new ServiceException(ex);
	}
	
	cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void raiseException (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(raiseException)>> ---
		// @sigtype java 3.5
		// [i] field:0:required errorMessage
		IDataCursor idcPipeline = pipeline.getCursor();
		
		String strErrorMessage = null;
		if (idcPipeline.first("errorMessage"))
		{
			strErrorMessage = (String)idcPipeline.getValue();
		}
		
		
		idcPipeline.destroy();
		
		throw new ServiceException(strErrorMessage);
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	// --- <<IS-END-SHARED>> ---
}

