package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class prt

{
	// ---( internal utility methods )---

	final static prt _instance = new prt();

	static prt _newInstance() { return new prt(); }

	static prt _cast(Object o) { return (prt)o; }

	// ---( server methods )---




	public static final void getContextID (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getContextID)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:1:required context
		com.wm.app.b2b.server.InvokeState is = com.wm.app.b2b.server.InvokeState.getCurrentState();
		com.wm.app.audit.IAuditRuntime ar = is.getAuditRuntime();
		String[] context = ar.getContextStack();
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "context", context );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

