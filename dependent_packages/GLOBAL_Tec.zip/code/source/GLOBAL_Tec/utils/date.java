package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class date

{
	// ---( internal utility methods )---

	final static date _instance = new date();

	static date _newInstance() { return new date(); }

	static date _cast(Object o) { return (date)o; }

	// ---( server methods )---




	public static final void convertSecondsToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertSecondsToDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dateFormat
		// [i] field:0:required seconds
		// [o] field:0:required date

	IDataCursor plc = pipeline.getCursor();

	String strSeconds = null;
	if (plc.first("seconds"))
	{
		strSeconds = (String)plc.getValue();
	}
	else
	{
		throw new ServiceException("seconds must be supplied!");
	} 
	String strDateFormat = null;
	if (plc.first("dateFormat"))
	{
		strDateFormat = (String)plc.getValue();
	}
	else
	{
		throw new ServiceException("dateFormat must be supplied!");
	}
	
	long seconds = Long.parseLong(strSeconds)*1000;
	Date fdate = new Date(seconds);

	SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
	String strDate = sdf.format(fdate);

	if (plc.first("date")) plc.delete();
	plc.insertAfter("date", "" + strDate );
	plc.destroy(); 
 
		// --- <<IS-END>> ---

                
	}



	public static final void convertStringToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertStringToDate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateTimeString
		// [i] field:0:required dateTimeFormat
		// [o] object:0:required date
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dateTimeString = IDataUtil.getString( pipelineCursor, "dateTimeString" );
		String	dateTimeFormat = IDataUtil.getString( pipelineCursor, "dateTimeFormat" );
		pipelineCursor.destroy();
		
		// input validation
		if(dateTimeString == null || dateTimeString.equals("") ) {
		throw new ServiceException("dateTimeString is missing");
		}
		
		if(dateTimeFormat == null || dateTimeFormat.equals("") ) {
		throw new ServiceException("dateTimeFormat is missing");
		}
			
		
		// check if the input string and format match together
		try
		{
		// Format the current time.
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		sdf.setLenient(false);
		Date parsedDate = sdf.parse(dateTimeString);
		}
		catch (Exception e)
		{
		throw new ServiceException("dateTimeString \'" + dateTimeString + "\' doesn't match the format \'" + dateTimeFormat + "\'" );
		}
		
		
		// convert string to date
		DateFormat formatter = new SimpleDateFormat(dateTimeFormat);
			
		Date date;
		try {
		date = formatter.parse(dateTimeString);
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "date", date );
		pipelineCursor_1.destroy();
		} catch (ParseException e) {
		// TODO Auto-generated catch block
		throw new ServiceException(e);
		
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void epochToTimestampString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(epochToTimestampString)>> ---
		// @sigtype java 3.5
		// [i] field:0:required epoch
		// [i] field:0:required resultFormat
		// [o] field:0:required resultString
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	epochString = IDataUtil.getString( pipelineCursor, "epoch" );
		String	dateTimeFormat = IDataUtil.getString( pipelineCursor, "resultFormat" );
		
		// input validation
		if(epochString == null || epochString.equals("") ) {
		throw new ServiceException("epoch is missing");
		}
		
		if(dateTimeFormat == null || dateTimeFormat.equals("") ) {
		throw new ServiceException("resultFormat is missing");
		}
		
		Long milis;	
		String outputString = null;
		
		try
		{
			milis = Long.decode(epochString);
			
			
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateTimeFormat);
		
			outputString = Instant.ofEpochMilli(milis).atZone(ZoneId.of("Europe/Zurich")).format(dateFormatter).toString();
			
			IDataUtil.put( pipelineCursor, "resultString", outputString);
			
		}
		catch (Exception e)
		{
		throw new ServiceException(e.getMessage());
		}
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentDateInSeconds (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentDateInSeconds)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required seconds
			
		
		IDataCursor plc = pipeline.getCursor();
		
		Date now = new Date();
		try {	
			if (plc.first("seconds")) plc.delete();
			plc.insertAfter("seconds", "" + now.getTime()/1000 );
			plc.destroy();
		} catch (Exception e)
			{}
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentUnixTime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentUnixTime)>> ---
		// @sigtype java 3.5
		// [o] field:0:required epoch
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "epoch", String.valueOf(System.currentTimeMillis()/1000));
			
		// --- <<IS-END>> ---

                
	}



	public static final void timestampStringToEpoch (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(timestampStringToEpoch)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateTimeString
		// [i] field:0:required dateTimeFormat
		// [o] field:0:required epoch
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dateTimeString = IDataUtil.getString( pipelineCursor, "dateTimeString" );
		String	dateTimeFormat = IDataUtil.getString( pipelineCursor, "dateTimeFormat" );
		
		// input validation
		if(dateTimeString == null || dateTimeString.equals("") ) {
		throw new ServiceException("dateTimeString is missing");
		}
		
		if(dateTimeFormat == null || dateTimeFormat.equals("") ) {
		throw new ServiceException("dateTimeFormat is missing");
		}
		
		Long milis;	
		
		try
		{
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(dateTimeFormat);
			//TODO: Improve this condition detecting timestamp/date
			if(!dateTimeFormat.contains("HH")&&!dateTimeFormat.contains("hh")){
				LocalDate date = LocalDate.parse(dateTimeString, DateTimeFormatter.ofPattern(dateTimeFormat));
				ZonedDateTime zdt = date.atStartOfDay(ZoneId.of("Europe/Zurich"));
				milis = zdt.toInstant().toEpochMilli();
			} else {
				LocalDateTime date = LocalDateTime.parse(dateTimeString, inputFormatter);
				ZonedDateTime zdt = date.atZone(ZoneId.of("Europe/Zurich"));
				milis = zdt.toInstant().toEpochMilli();
			}
			
			IDataUtil.put( pipelineCursor, "epoch", String.valueOf(milis));
			
		}
		catch (Exception e)
		{
		throw new ServiceException("dateTimeString \'" + dateTimeString + "\' doesn't match the format \'" + dateTimeFormat + "\'" );
		}
		
			
		// --- <<IS-END>> ---

                
	}
}

