package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.regex.*;
// --- <<IS-END-IMPORTS>> ---

public final class regex

{
	// ---( internal utility methods )---

	final static regex _instance = new regex();

	static regex _newInstance() { return new regex(); }

	static regex _cast(Object o) { return (regex)o; }

	// ---( server methods )---




	public static final void find (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(find)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] recref:0:required resultSet GLOBAL_Tec.utils.regex:resultSet
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		
		Matcher matcher = pattern.matcher(input);
		
		int sets = 0;
		
		while (matcher.find())
		{
			sets++;
		}
		
		matcher.reset();
		
		int i = 0;
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// resultSet
		IData	resultSet = IDataFactory.create();
		IDataCursor resultSetCursor = resultSet.getCursor();
		
		
		// resultSet.result
		IData[]	result = new IData[sets];
		
		while (matcher.find())
		{
			result[i] = IDataFactory.create();
			IDataCursor resultCursor = result[i].getCursor();
			IDataUtil.put( resultCursor, "text", matcher.group() );
			IDataUtil.put( resultCursor, "start", Integer.toString(matcher.start()));
			IDataUtil.put( resultCursor, "end", Integer.toString(matcher.end()));
			resultCursor.destroy();
			IDataUtil.put( resultSetCursor, "result", result );
			resultSetCursor.destroy();
		
			i++;
		}
		
		IDataUtil.put( pipelineCursor_1, "resultSet", resultSet );
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void findGroups (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(findGroups)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] record:0:required resultSet
		// [o] - field:0:required resultCount
		// [o] - record:1:required result
		// [o] -- field:0:required fullMatch
		// [o] -- field:0:required groupCount
		// [o] -- record:1:required groups
		// [o] --- field:0:required groupNumber
		// [o] --- field:0:required groupMatch
			
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		
		Matcher matcher = pattern.matcher(input);
		
		int sets = 0;
		
		while (matcher.find())
		{
			sets++;
		}
		
		matcher.reset();
		
		int i = 0;
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// resultSet
		IData	resultSet = IDataFactory.create();
		IDataCursor resultSetCursor = resultSet.getCursor();
		
		
		// resultSet.result
		IData[]	result = new IData[sets];
		
		
		while (matcher.find())
		{
			result[i] = IDataFactory.create();
			IDataCursor resultCursor = result[i].getCursor();
			
			int subGroupCount = matcher.groupCount();
			IData[]	subResult = new IData[subGroupCount];
			
			for (int j=0;j<subGroupCount;j++){
				subResult[j] = IDataFactory.create();
				IDataCursor subResultCursor = subResult[j].getCursor();
				IDataUtil.put( subResultCursor, "groupNumber", Integer.toString(j+1));
				IDataUtil.put( subResultCursor, "groupMatch", matcher.group(j+1) );
				subResultCursor.destroy();
			}
			
			IDataUtil.put( resultCursor, "fullMatch", matcher.group() );
			IDataUtil.put( resultCursor, "groupCount", Integer.toString(subGroupCount) );
			IDataUtil.put( resultCursor, "groups", subResult );
			resultCursor.destroy();
			
			IDataUtil.put( resultSetCursor, "result", result );
			
			resultSetCursor.destroy();
		
			i++;
		}
		IDataUtil.put( resultSetCursor, "resultCount", Integer.toString(sets) );
		IDataUtil.put( pipelineCursor_1, "resultSet", resultSet );
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void lookingAt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(lookingAt)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] field:0:required match
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		String match = "false";
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		
		if (matcher.lookingAt())
		{
			match = "true";
		}
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "match", match );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void matches (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(matches)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] field:0:required match
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		String match = "false";
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		
		if (matcher.matches())
		{
			match = "true";
		}
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "match", match );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void replaceAll (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(replaceAll)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [i] field:0:required replacement
		// [o] field:0:required output
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		String replacement = IDataUtil.getString( pipelineCursor, "replacement" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		String output = matcher.replaceAll(replacement);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "output", output );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void replaceFirst (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(replaceFirst)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [i] field:0:required replacement
		// [o] field:0:required output
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		String replacement = IDataUtil.getString( pipelineCursor, "replacement" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		String output= matcher.replaceFirst(replacement);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "output", output );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void split (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(split)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] field:1:required items
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		
		String items[] = pattern.split(input);
		for (int i=0; i < items.length; i++)
		{
			System.out.println(items[i]);
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "items", items );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void splitLimit (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(splitLimit)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [i] field:0:required limit
		// [o] field:1:required items
		// Toni Immordino
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String regex = IDataUtil.getString( pipelineCursor, "regex" );
		String input = IDataUtil.getString( pipelineCursor, "input" );
		String limit = IDataUtil.getString( pipelineCursor, "limit" );
		pipelineCursor.destroy();
		
		Pattern pattern = Pattern.compile(regex);
		
		String items[] = pattern.split(input, Integer.parseInt(limit));
		for (int i=0; i < items.length; i++)
		{
			System.out.println(items[i]);
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "items", items );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

