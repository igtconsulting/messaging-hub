package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.ibm.icu.impl.UResource.Array;
import com.wm.lang.ns.NSField;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSRecord;
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.util.List;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
// --- <<IS-END-IMPORTS>> ---

public final class document

{
	// ---( internal utility methods )---

	final static document _instance = new document();

	static document _newInstance() { return new document(); }

	static document _cast(Object o) { return (document)o; }

	// ---( server methods )---




	public static final void covnertStringFieldsToMatchDocument (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(covnertStringFieldsToMatchDocument)>> ---
		// @sigtype java 3.5
		// [i] record:0:required document
		// [i] field:0:required documentType
		// [o] record:0:required document
		IDataCursor pipelineCursor = pipeline.getCursor();
		String documentType = IDataUtil.getString( pipelineCursor, "documentType" );
		IData documentData = (IData) IDataUtil.get(pipelineCursor,  "document");
		
		if(!documentType.contains(":") && documentType.contains(".")) {
			throw new ServiceException("Supplied documentType path '"+documentType+"' is not valid path to document.");
		}
				
		Namespace ns = Namespace.current();
		NSName nsName = NSName.create(documentType);
		NSRecord baseRecord = (NSRecord) ns.getNode(nsName);
		
		documentData = convertIDataTypes(documentData, baseRecord); 
		
		IDataUtil.put(pipelineCursor, "document", documentData);
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void createClone (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createClone)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required document
		// [i] field:0:optional depth {"shallow","deep"}
		// [o] record:0:required clone
		IDataCursor cursor = pipeline.getCursor();
		IData document = IDataUtil.getIData(cursor, "document");
		String depth = IDataUtil.getString(cursor, "depth");
		try
		{
		  if (document != null)
		  {
		    IData clonedData = null;
		    if ("deep".equalsIgnoreCase(depth))
		    {
		      clonedData = IDataUtil.deepClone(document);
		    }
		    else
		    {
		      clonedData = IDataUtil.clone(document);
		    }
		    IDataUtil.put(cursor, "clone", clonedData);
		  }
		}
		catch (IOException ioe)
		{
		  throw new ServiceException(ioe);
		}
		finally
		{
		  cursor.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringify (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringify)>> ---
		// @sigtype java 3.5
		// [i] record:0:required document
		// [i] field:0:required recurse {"false","true"}
		// [o] record:0:required document
		IDataCursor cursor = pipeline.getCursor();
		
		
		Object obj = IDataUtil.get( cursor, "document" );
		Boolean recurse = IDataUtil.getBoolean(cursor, "recurse");
		
		obj = transformIData((IData) obj, recurse);
		
		IDataUtil.put( cursor, "result", obj );
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
		
	public static IData transformIData(IData document, boolean recurse)  throws ServiceException {
        if (!(document instanceof IData)) return null;
        IDataCursor cursor = document.getCursor();
        
        if(!cursor.first()) return document;
        
        boolean moreData = true;
        while (moreData){
        	Object obj = cursor.getValue();
        	String key = cursor.getKey();
        	
        	if (obj instanceof IData || obj instanceof IData[]){
        		if (recurse){
        			if (obj instanceof IData){
        				obj = transformIData((IData) obj, recurse);
        			}else if (obj instanceof IData[]){
        				for (Object tobj : (Object[]) obj){
        					tobj = transformIData((IData) tobj, recurse);
        				}
        			}
        		}else{
        			moreData=cursor.hasMoreData();
        			continue;
        		}
        	} else {
        		if (Objects.nonNull(obj)) {
        			
        			if ( obj.getClass().isArray() ) {
        				
        				ArrayList<String> newList = new ArrayList<String>();
        				for (Object tobj : (Object[]) obj){
        					newList.add(String.valueOf(tobj));
        				}
        				obj = Arrays.copyOf(newList.toArray(), newList.size(), String[].class);
    	        	} else {
    	        		obj = String.valueOf(obj);
    	        	}
        		}
        	}
        	cursor.insertBefore(key, obj);
        	cursor.next();
        	moreData=cursor.delete();   
        	 	        	
        }
        cursor.destroy();
        return document;
	}
	
	public static IData convertIDataTypes(IData source, NSRecord schema) throws ServiceException {
		IDataCursor cursor = source.getCursor();
	
		while(cursor.next()) {
			String nextKey = cursor.getKey();
			Object nextData = cursor.getValue();
			
			NSField schemaField = schema.getFieldByName(nextKey);
			if (Objects.nonNull(schemaField)){
				if (nextData instanceof IData) {
					cursor.setValue(convertIDataTypes((IData) nextData, (NSRecord) schemaField));
						
				} else if (nextData instanceof IData[]) {
					
					final IData[] subDocuments = (IData[]) nextData;
					for (IData subDocument : subDocuments) {
						subDocument = convertIDataTypes( subDocument, (NSRecord) schemaField);
					}
					cursor.setValue(subDocuments);
				} else  { 
					String expectedType = schemaField.getJavaWrapperTypeString();
					try {
						Class expectedClass = Class.forName(expectedType);
						
						if (!nextData.getClass().equals(expectedClass) ){
							Object val = null;
							switch (expectedType) {
							  case "UNKNOWN":
							    val = nextData.toString();
							    break;
							  case "java.lang.Boolean":
							    val = Boolean.valueOf(nextData.toString());
							    break;
							  case "java.lang.Double":
								  val = Double.valueOf(nextData.toString());
							    break;
							  case "java.lang.Integer":
								  val = Integer.valueOf(nextData.toString());
							    break;
							  case "java.lang.Long":
								  val = Long.valueOf(nextData.toString());
							    break;
							  case "java.lang.Float":
								  val = Float.valueOf(nextData.toString());
							    break;	  
							}
							if (Objects.nonNull(val)) cursor.setValue(val);
						}							
							
					} catch (ClassNotFoundException e) {
						throw new ServiceException(e);
					}
				}
			}
		}
		cursor.destroy();
		
		return source;
	}
	
	

	
	// --- <<IS-END-SHARED>> ---
}

