package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.wm.util.Debug;
import java.io.*;
import java.util.*;
import java.lang.System;
import com.wm.app.b2b.server.*;
import com.wm.util.Table;
import java.text.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class serverInfo

{
	// ---( internal utility methods )---

	final static serverInfo _instance = new serverInfo();

	static serverInfo _newInstance() { return new serverInfo(); }

	static serverInfo _cast(Object o) { return (serverInfo)o; }

	// ---( server methods )---




	public static final void getServerInformation (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerInformation)>> ---
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required primaryPort
		// [o] field:0:required currentPort
		
			IDataCursor idcPipeline = pipeline.getCursor();
		
			String strServerName = ServerAPI.getServerName();
			int intCurrentPort = ServerAPI.getCurrentPort();
		
			IData listenerInfo = null;
			Integer intPrimaryPort = null;
		
			try
			{
				IData results = Service.doInvoke("wm.server.net.listeners", "getPrimaryListener", pipeline);
				IDataUtil.merge(results, pipeline);
		
			}
			catch(Exception e)
			{
				throw new ServiceException("Could not invoke wm.server.net.listeners:getPrimaryListener: " + e);
			}
		
			if (idcPipeline.first("primary"))
			{
				listenerInfo = (IData)idcPipeline.getValue();
				idcPipeline.delete();
			}
			IDataCursor idcListenerInfo = listenerInfo.getCursor();
		
			if (idcListenerInfo.first("port"))
			{
				intPrimaryPort = (Integer)idcListenerInfo.getValue();
			}
		
			idcPipeline.insertAfter("serverName", strServerName);
			idcPipeline.insertAfter("primaryPort", intPrimaryPort.toString());
			idcPipeline.insertAfter("currentPort", Integer.toString(intCurrentPort));
		
		// Clean up IData cursors
			idcListenerInfo.destroy();
			idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	/** Used by "deepConvert"
	  * 
	  * @author Ryan Johnston, Professional Services, webMethods, Inc.
	  * @version 1.0
	  */
	private static final Values convert(Hashtable hT){
		//Following statement gets all arrays in this object.
		boolean nullFlag = false;
		Object[] hTArray = hT.values().toArray();
		Enumeration hTEnumeration = hT.keys();
		Values outbound = new Values();
	
		for(int i=0;i<hTArray.length;i++){
			String key = (String)hTEnumeration.nextElement();
			if(hTArray[i] instanceof java.lang.String){
					outbound.setValue(key,(String)hTArray[i]);
			}
			else if(hTArray[i] instanceof java.util.Hashtable){
				Values internalObject = convert((Hashtable)hTArray[i]);
				if(internalObject == null){
					nullFlag = true;
					return null;
				}
				
				outbound.setValue(key,internalObject);
			}
			else{
				return null;
			}
		}
		return outbound; 
	}
	
	public static final int MAXSLEEP = 3600000;  // one hr
	// --- <<IS-END-SHARED>> ---
}

