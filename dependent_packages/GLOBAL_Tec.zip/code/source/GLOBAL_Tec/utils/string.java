package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
// --- <<IS-END-IMPORTS>> ---

public final class string

{
	// ---( internal utility methods )---

	final static string _instance = new string();

	static string _newInstance() { return new string(); }

	static string _cast(Object o) { return (string)o; }

	// ---( server methods )---




	public static final void normalizeString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(normalizeString)>> ---
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] field:0:required result
		IDataCursor pipelineCursor = pipeline.getCursor();
		String inputString = IDataUtil.getString( pipelineCursor, "input" );
		
		IDataUtil.put( pipelineCursor, "result", Normalizer.normalize(inputString, Normalizer.Form.NFD));
		
				
		//Pattern p = Pattern.compile("[^a-zA-Z0-9\\s]");
		//Matcher m = p.matcher(normalized);
		
		//IDataUtil.put( pipelineCursor, "result", normalized.replaceAll(p.toString(), ""));
		//List<String> matches = new ArrayList<String>();
		
		//String[] matches = new String[];
		
		//while(m.find()){
		//	if(!matches.contains(m.group()))
		//		matches.add(m.group());
		//}
		//IDataUtil.put( pipelineCursor, "removedCharacters",  matches.toArray(new String[0]));
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

