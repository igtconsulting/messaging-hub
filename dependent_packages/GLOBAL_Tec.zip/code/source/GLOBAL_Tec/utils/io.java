package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import javax.activation.MimetypesFileTypeMap;
import java.net.*;
// --- <<IS-END-IMPORTS>> ---

public final class io

{
	// ---( internal utility methods )---

	final static io _instance = new io();

	static io _newInstance() { return new io(); }

	static io _cast(Object o) { return (io)o; }

	// ---( server methods )---




	public static final void getFileMimeContentType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFileMimeContentType)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required contentType
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		
		String contentType = getContentType(filename);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "contentType", contentType );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getFilenameFromAbsoluteFilename (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilenameFromAbsoluteFilename)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required value
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		
		File f = new File(filename);
		String result = f.getName() ;
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", result );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readLineFromStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readLineFromStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inputStream
		// [o] field:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		InputStream	inputStream = (InputStream) IDataUtil.get( pipelineCursor, "inputStream");
		BufferedReader bufferedReader = (BufferedReader) IDataUtil.get( pipelineCursor, "bufferedReader");
		
		if (Objects.isNull(inputStream)){
			throw new ServiceException("inputStream missing");
		}
		
		if (Objects.isNull(bufferedReader) & Objects.isNull(inputStream)){
			throw new ServiceException("bufferedReader and inputStream missing");
		}
		
		if (Objects.isNull(bufferedReader)){
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		}
		
		String output = null;
		
		try {
			output = bufferedReader.readLine();
			if (Objects.isNull(output)) {
				bufferedReader.close();
			}
		} catch (IOException e) {
			throw new ServiceException(e);
		}
		
		// pipeline
		IDataUtil.put( pipelineCursor, "output", output );
		IDataUtil.put( pipelineCursor, "bufferedReader", bufferedReader );
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static Hashtable<String,String> mimeExtention = new Hashtable<String,String>();
	
	public static String getContentType(String filename) {
		String suffix = filename.substring(filename.lastIndexOf(".")+1).toUpperCase();
		String contentType = null;
	
		if (mimeExtention.containsKey(suffix)) {
			contentType = mimeExtention.get(suffix);
		} else {
			FileNameMap fileNameMap = URLConnection.getFileNameMap();
			contentType = fileNameMap.getContentTypeFor(filename);
		}
		if (contentType == null) contentType = "application/octet-stream";
	
		return contentType;
	}
	// --- <<IS-END-SHARED>> ---
}

