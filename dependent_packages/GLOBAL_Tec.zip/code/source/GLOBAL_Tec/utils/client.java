package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.Normalizer;
import java.util.Properties;
import java.util.ArrayList;
import java.util.List;
import javax.mail.*;
import javax.mail.search.*;
import javax.mail.Multipart;
import javax.mail.internet.*;
import javax.mail.Message.RecipientType;
import com.wm.util.JournalLogger;
// --- <<IS-END-IMPORTS>> ---

public final class client

{
	// ---( internal utility methods )---

	final static client _instance = new client();

	static client _newInstance() { return new client(); }

	static client _cast(Object o) { return (client)o; }

	// ---( server methods )---




	public static final void pop3Reader (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(pop3Reader)>> ---
		// @sigtype java 3.5
		// [i] field:0:required host
		// [i] field:0:required user
		// [i] field:0:required token
		// [i] field:0:required port
		// [o] record:1:required transport
		// [o] - field:0:required protocol
		// [o] - record:0:required email
		// [o] -- object:0:required filename
		// [o] -- object:0:required content
		// [o] -- field:0:required contenttype
		// [o] -- field:0:required subject
		// [o] -- field:0:required sentdate
		// [o] -- field:1:required to
		// [o] -- field:1:required from
		// [o] -- field:1:required replyto
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String host = IDataUtil.getString(pipelineCursor, "host");
		String user = IDataUtil.getString(pipelineCursor, "user");
		String token = IDataUtil.getString(pipelineCursor, "token");
		String port = IDataUtil.getString(pipelineCursor, "port"); // "995"
		
		List<IData> docList = new ArrayList<IData>();
		
		/*
		// Console output to stream - create a stream to hold the output
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		// IMPORTANT: Save the old System.out!
		PrintStream old = System.out;
		// Tell Java to use your special stream
		System.setOut(ps);
		*/
		
		try {			
						
			Properties properties = new Properties();
			
		    properties.put("mail.pop3s.port", port);
			properties.put("mail.pop3s.forgettopheaders", "true");
			
			properties.put("mail.pop3s.auth.mechanisms", "XOAUTH2");
		    properties.put("mail.pop3s.auth.login.disable", "true");		// If true, prevents use of the USER and PASS commands. Default is false.
		    properties.put("mail.pop3s.auth.plain.disable", "true");		// If true, prevents use of the AUTH PLAIN command. Default is false.
		    properties.put("mail.pop3s.auth.xoauth2.disable","false");		// If true, prevents use of the AUTHENTICATE XOAUTH2 command. Hence set to false.
		    properties.put("mail.pop3s.auth.xoauth2.two.line.authentication.format", "true");  // If true, splits authentication command on two lines. Default is false.
		
		    properties.put("mail.pop3s.connectiontimeout", 15000);
		    properties.put("mail.pop3s.timeout", 15000);
		    
		    //properties.put("mail.debug", "true");
		    //properties.put("mail.debug.auth", "true");
		    
			properties.put("mail.pop3s.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			properties.put("mail.pop3s.socketFactory.fallback", "false");
		    properties.put("mail.pop3s.socketFactory.port", port);
			
			properties.put("mail.mime.address.strict", "false");
			
			Session session = Session.getInstance(properties);
			//session.setDebug(true);	
			Store store = session.getStore("pop3s");			
			store.connect(host, user, token);
			
			/*
			// Console output to stream - Put things back
			System.out.flush();
			System.setOut(old);
			*/
			
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);
		
			// Get the list of inbox messages
			Message[] messages = inbox.getMessages();
			//Flags seen = new Flags(Flags.Flag.DELETED);
			//FlagTerm unseenFlagTerm = new FlagTerm(seen, false);
			//Message[] messages = inbox.search(unseenFlagTerm);
			
			for (int mi = 0; mi < messages.length; mi++) {
				
				Address fromA[] = messages[mi].getFrom();
				Address toA[] = messages[mi].getRecipients(RecipientType.TO);
				Address replytoA[] = messages[mi].getReplyTo();
				Address ccA[] = messages[mi].getRecipients(RecipientType.CC);
				Address bccA[] = messages[mi].getRecipients(RecipientType.BCC);
				
				String to[] = null;
				String from[] = null;
				String cc[] = null;
				String bcc[] = null;
				String replyto[] = null;
				
				if (toA != null && toA.length > 0) {
					to = new String[toA.length];
					for (int i = 0; i < toA.length; i++) { 
						to[i] = toA[i].toString();
					}
				}
				if (fromA != null && fromA.length > 0) {
					from = new String[fromA.length];
					for (int i = 0; i < fromA.length; i++) { 
					    from[i] = fromA[i].toString();
					}
				}
				if (replytoA != null && replytoA.length > 0) {
					replyto = new String[replytoA.length];
					for (int i = 0; i < replytoA.length; i++) { 
						replyto[i] = replytoA[i].toString();
					}
				}
				if (ccA != null && ccA.length > 0) {
					cc = new String[ccA.length];
					for (int i = 0; i < ccA.length; i++) { 
						cc[i] = ccA[i].toString();
					}
				}
				if (bccA != null && bccA.length > 0) {
					bcc = new String[bccA.length];
					for (int i = 0; i < bccA.length; i++) { 
						bcc[i] = bccA[i].toString();
					}
				}
		
				String subject = messages[mi].getSubject();
				String sentdate = messages[mi].getSentDate().toString();
				
				//IDataUtil.put(pipelineCursor, "classname", messages[mi].getContent().getClass().getName());
				if (messages[mi].getContent().getClass().getName() == "com.wm.net.mime.MimeMultipart_WM") {
					
					Multipart multipart = (Multipart) messages[mi].getContent();
					
					for (int k = 0; k < multipart.getCount(); k++) {
				    	IData email = IDataFactory.create();
						IDataCursor emailCursor = email.getCursor();
							
						IData transport = IDataFactory.create();
						IDataCursor transportCursor = transport.getCursor();
							 
						BodyPart bodyPart = multipart.getBodyPart(k);  
						InputStream attachmentInputStream = bodyPart.getInputStream();
						byte[] data = getBytesFromInputStream(attachmentInputStream);					
						int len = data.length;
						ByteArrayInputStream blockStream = new ByteArrayInputStream(data, 0, len);   
						
						IDataUtil.put(transportCursor, "protocol", "email");
						
						String filename = bodyPart.getFileName();
						
						if (filename != null) {
							String decoded = MimeUtility.decodeText(filename);
							filename = Normalizer.normalize(decoded, Normalizer.Form.NFC);
						}
						
						IDataUtil.put(emailCursor, "filename", filename);
						IDataUtil.put(emailCursor, "content", blockStream);
						IDataUtil.put(emailCursor, "contenttype", bodyPart.getContentType());	
						IDataUtil.put(emailCursor, "subject", subject);
						IDataUtil.put(emailCursor, "sentdate", sentdate);
						
						IDataUtil.put(emailCursor, "to", to);
						IDataUtil.put(emailCursor, "from", from);						
						if (cc != null) IDataUtil.put(emailCursor, "cc", cc);
						if (bcc != null) IDataUtil.put(emailCursor, "bcc", bcc);
						
						IDataUtil.put(emailCursor, "replyto", replyto);
						IDataUtil.put(transportCursor, "email", email);
						
						docList.add(transport);
						
						emailCursor.destroy();
						transportCursor.destroy();
					}
					messages[mi].setFlag(Flags.Flag.DELETED, true);
				}
			}
			
			inbox.close(true);
			store.close();
		
			IData simpleDocList[] = new IData[docList.size()];
			docList.toArray(simpleDocList);
			IDataUtil.put(pipelineCursor, "transport", simpleDocList);
		}
		catch(Exception e) {
			/*
			JournalLogger.log(4,90,3,"[POP3_READER]","Error" + "\n" + baos.toString());
			// Console output to stream - Put things back
			System.out.flush();
			System.setOut(old);
			*/
			throw new ServiceException(e.getMessage());
			
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static byte[] getBytesFromInputStream(InputStream inputStream) throws IOException {
		BufferedInputStream bis = null;
		ByteArrayOutputStream bos = null;
		try {
			bis = new BufferedInputStream(inputStream);
			// write it to a byte[] using a buffer since we don't know the exact
			// image size
			byte[] buffer = new byte[1024];
			bos = new ByteArrayOutputStream();
			int i = 0;
			while (-1 != (i = bis.read(buffer))) {
				bos.write(buffer, 0, i);
			}
			byte[] data = bos.toByteArray();
			return data;
		}
		catch (IOException e) {
			throw new IOException(e.getMessage());
		}
		finally {
			try {
				if (bis != null)
					bis.close();
				if (bos != null)
					bos.close();
			}
			catch (IOException e) {
				// ignore
			}
		}
	}
	// --- <<IS-END-SHARED>> ---
}

