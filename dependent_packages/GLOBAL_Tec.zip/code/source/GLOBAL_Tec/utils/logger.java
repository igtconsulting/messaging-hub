package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.Date;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
// --- <<IS-END-IMPORTS>> ---

public final class logger

{
	// ---( internal utility methods )---

	final static logger _instance = new logger();

	static logger _newInstance() { return new logger(); }

	static logger _cast(Object o) { return (logger)o; }

	// ---( server methods )---




	public static final void logInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(logInfo)>> ---
		// @sigtype java 3.5
		// [i] field:0:required message
		// [i] field:0:required logName
		// [i] field:0:required logLevel {"INFO","WARNING","SEVERE"}
		System.setProperty("java.util.logging.SimpleFormatter.format", "[%1$tc] %4$s: %5$s%n"); 
		
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		String message = (String) IDataUtil.get(pipelineCursor, "message");
		String logname = (String) IDataUtil.get(pipelineCursor, "logName");
		String logLevelStr = (String) IDataUtil.get(pipelineCursor, "logLevel");
		
		
		Logger logger = Logger.getLogger(logname);
		Handler fileHandler  = null;
		Formatter simpleFormatter = null;
		try{
		    fileHandler  = new FileHandler("./logs/"+logname, true);
		    logger.addHandler(fileHandler);
		    simpleFormatter = new SimpleFormatter(){
		          private static final String format = "[%1$tF %1$tT] [%2$s] %3$s %n";
		
		          @Override
		          public synchronized String format(LogRecord lr) {
		              return String.format(format,
		                      new Date(lr.getMillis()),
		                      lr.getLevel().getLocalizedName(),
		                      lr.getMessage()
		              );
		          }
		      };
		
		    fileHandler.setFormatter(simpleFormatter);
		    fileHandler.setLevel(Level.ALL);
		    logger.setLevel(Level.ALL);
		    
		    Level logLevel = Level.INFO;
		    if (logLevelStr != null) {
		    	switch (logLevelStr) {
			    case "INFO":
			    	logLevel = Level.INFO;
			    	break;
			    case "WARNING":
			    	logLevel = Level.WARNING;
			    	break;
			    case "SEVERE":
			    	logLevel = Level.SEVERE;
			    }
		    } else {
		    	logLevel = Level.INFO;
		    }
		    
		    logger.log(logLevel, message);
		    
		    fileHandler.close();
		    logger.removeHandler(fileHandler);
		    
		}catch(IOException exception){
			logger.log(Level.SEVERE, "Error occur in FileHandler.", exception);
		}
		
		
			
		// --- <<IS-END>> ---

                
	}
}

