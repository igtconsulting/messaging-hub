package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.ns.NSName;
// --- <<IS-END-IMPORTS>> ---

public final class thread

{
	// ---( internal utility methods )---

	final static thread _instance = new thread();

	static thread _newInstance() { return new thread(); }

	static thread _cast(Object o) { return (thread)o; }

	// ---( server methods )---




	public static final void doThreadedInvoke (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(doThreadedInvoke)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [i] record:0:required input
		// [o] field:0:required status
		IDataCursor pc = pipeline.getCursor();
		String service = IDataUtil.getString(pc, "serviceName");
		IData input = IDataUtil.getIData(pc, "input");
		
		boolean invoked = true;
		try {
			NSName nsname = NSName.create(service);
			Service.doThreadInvoke(nsname, input, 2000);
		} catch (Exception e) {
			invoked = false;
		}
		
		IDataUtil.put(pc, "status", String.valueOf(invoked));
		pc.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

