package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Calendar;
import java.util.Date;
import javax.crypto.SecretKey;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PrivateKey;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import java.util.Arrays;
import java.util.List;
import sun.security.rsa.RSAPrivateCrtKeyImpl;
import java.security.spec.PKCS8EncodedKeySpec;
// --- <<IS-END-IMPORTS>> ---

public final class jwt

{
	// ---( internal utility methods )---

	final static jwt _instance = new jwt();

	static jwt _newInstance() { return new jwt(); }

	static jwt _cast(Object o) { return (jwt)o; }

	// ---( server methods )---




	public static final void computeJWTtoken (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(computeJWTtoken)>> ---
		// @sigtype java 3.5
		// [i] field:0:required jwsAlgorithm {"HS256 (Shared key)","HS384 (Shared key)","HS512 (Shared key)","ES256 (ECDSA Private key)","ES384 (ECDSA Private key)","ES512 (ECDSA Private key)","RS256 (RSA Private key)","RS384 (RSA Private key)","RS512 (RSA Private key)","PS256 (RSA Private key)","PS384 (RSA Private key)"}
		// [i] field:0:optional sharedKey
		// [i] object:0:optional privateKey
		// [i] field:0:required audience
		// [i] field:0:required expirationHours
		// [i] field:0:required subject
		// [i] field:0:required issuer
		// [i] field:0:required nbf {"no","yes"}
		// [i] field:0:required iat {"no","yes"}
		// [i] record:1:required payloadClaims
		// [i] - field:0:required key
		// [i] - field:0:required value
		// [i] record:1:required headerClaims
		// [i] - field:0:required key
		// [i] - field:0:required value
		// [o] field:0:required jwtToken
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String audience = IDataUtil.getString( pipelineCursor, "audience" ); 
		int expiration = IDataUtil.getInt( pipelineCursor, "expirationHours", -1); 
		String subject = IDataUtil.getString( pipelineCursor, "subject" ); 
		String issuer = IDataUtil.getString( pipelineCursor, "issuer" ); 
		String sharedKey = IDataUtil.getString( pipelineCursor, "sharedKey" ); 
		Object privateKey = IDataUtil.get( pipelineCursor, "privateKey" ); 
		String jwsAlgorithm = IDataUtil.getString( pipelineCursor, "jwsAlgorithm" ); 
		IData[] pclaims = IDataUtil.getIDataArray(pipelineCursor, "payloadClaims");
		IData[] hclaims = IDataUtil.getIDataArray(pipelineCursor, "headerClaims");
		String nbf = IDataUtil.getString( pipelineCursor, "nbf" ); 
		String iat = IDataUtil.getString( pipelineCursor, "iat" ); 
		
		try{
			
			//Remove comments from the jwsAlgorithm
			jwsAlgorithm = jwsAlgorithm.split(" ")[0];
			
			Date now = new Date();
			
			//Create jwt builder
			JwtBuilder jwtTokenBuilder = Jwts.builder().setHeaderParam("typ", "JWT");
			
			//Start input validation
			if(sharedKey == null && privateKey == null){
				throw new ServiceException("No key provided");
			}
			
			if(subject != null && subject != ""){
				jwtTokenBuilder.setSubject(subject);
			}
			if(audience != null && audience != ""){
				jwtTokenBuilder.setAudience(audience);
			}
			if(issuer != null && issuer != ""){
				jwtTokenBuilder.setIssuer(issuer);
			}
			if(expiration != -1){
				jwtTokenBuilder.setExpiration(addHours(now, expiration));
			}
			if(nbf != null && nbf != "no" && nbf != ""){
				jwtTokenBuilder.setNotBefore(now);
			}
			if(iat != null && iat != "no" && iat != ""){
				jwtTokenBuilder.setIssuedAt(now);
			}
			
			//Expand header section
			if(hclaims != null){
				List<IData> claimsList = Arrays.asList(hclaims);
				for (int i = 0; i < claimsList.size(); i++) {
					IDataCursor claimCursor = claimsList.get(i).getCursor();
					String key = IDataUtil.getString( claimCursor, "key" ); 
					String value = IDataUtil.getString( claimCursor, "value" ); 
					
					jwtTokenBuilder.setHeaderParam(key, value);
					
					claimCursor.destroy();
				}
			}
			
			//Fill payload section
			if(pclaims != null){
				List<IData> claimsList = Arrays.asList(pclaims);
				for (int i = 0; i < claimsList.size(); i++) {
					IDataCursor claimCursor = claimsList.get(i).getCursor();
					String key = IDataUtil.getString( claimCursor, "key" ); 
					String value = IDataUtil.getString( claimCursor, "value" ); 
					
					jwtTokenBuilder.claim(key, value);
					
					claimCursor.destroy();
				}
			}
			
			//Map correct sigAlgo -> algo, and keyFlag
			SignatureAlgorithm algo;
			String keyFlag;
			switch(jwsAlgorithm) {
				case "HS256":
					algo = SignatureAlgorithm.HS256;
					keyFlag = "sharedKey";
					break;
				case "HS384":
					algo = SignatureAlgorithm.HS384;
					keyFlag = "sharedKey";
					break;
				case "HS512":
					algo = SignatureAlgorithm.HS512;
					keyFlag = "sharedKey";
					break;
				case "ES256":
					algo = SignatureAlgorithm.ES256;
					keyFlag = "privateKey";
					break;
				case "ES384":
					algo = SignatureAlgorithm.ES384;
					keyFlag = "privateKey";
					break;
				case "ES512":
					algo = SignatureAlgorithm.ES512;
					keyFlag = "privateKey";
					break;
				case "RS256":
					algo = SignatureAlgorithm.RS256;
					keyFlag = "privateKey";
					break;
				case "RS384":
					algo = SignatureAlgorithm.RS384;
					keyFlag = "privateKey";
					break;
				case "RS512":
					algo = SignatureAlgorithm.RS512;
					keyFlag = "privateKey";
					break;
				case "PS256":
					algo = SignatureAlgorithm.PS256;
					keyFlag = "privateKey";
					break;
				case "PS384":
					algo = SignatureAlgorithm.PS384;
					keyFlag = "privateKey";
					break;
				case "PS512":
					algo = SignatureAlgorithm.PS512;
					keyFlag = "privateKey";
					break;
				default:
					throw new ServiceException("Incorrect input value for jwsAlgorithm");
			}
			
			//If keyFlag is "sharedKey" create JWT using sharedKey, when its "privateKey" use privateKey instead.
			if(keyFlag == "sharedKey"){
				SecretKey myKey = Keys.hmacShaKeyFor(sharedKey.getBytes(StandardCharsets.UTF_8));
				jwtTokenBuilder.signWith(myKey, algo);
			}else if(keyFlag == "privateKey"){			
				jwtTokenBuilder.signWith((RSAPrivateCrtKeyImpl) privateKey, algo);
			}
		
			//Create string and put it on service output
			String jwtToken = jwtTokenBuilder.compact();
			IDataUtil.put( pipelineCursor, "jwtToken", jwtToken );
			pipelineCursor.destroy();
		}
		catch(Exception e)
		{
		throw new ServiceException(e.getMessage());
		}	
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Date addHours(Date date, int hours) {
		Calendar cal = Calendar.getInstance(); // creates calendar
		cal.setTime(date); // sets calendar time/date
		cal.add(Calendar.HOUR_OF_DAY, hours); // adds one hour
		
		return cal.getTime();
	}
	// --- <<IS-END-SHARED>> ---
}

