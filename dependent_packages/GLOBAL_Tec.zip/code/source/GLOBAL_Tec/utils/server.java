package GLOBAL_Tec.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.MessageDigest;
import com.wm.app.b2b.server.*;
import com.wm.lang.ns.NSName;
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.app.b2b.server.ostore.CacheStore;
import com.wm.app.b2b.server.ostore.ServerCache;
import com.wm.app.b2b.server.ostore.ServiceCache;
import com.wm.app.b2b.server.stats.Statistics;
import com.wm.util.*;
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.ServerAPI;
import com.wm.app.b2b.server.ISRuntimeException;
import com.wm.lang.ns.NSService;
import java.net.InetAddress;
// --- <<IS-END-IMPORTS>> ---

public final class server

{
	// ---( internal utility methods )---

	final static server _instance = new server();

	static server _newInstance() { return new server(); }

	static server _cast(Object o) { return (server)o; }

	// ---( server methods )---




	public static final void waitForServerStartup (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(waitForServerStartup)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		Server.waitForStartup();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Random random = new Random();
	// --- <<IS-END-SHARED>> ---
}

