<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">pipelineAsDocument</value>
  <value name="encodeutf8">true</value>
  <value name="body">CUlEYXRhIHBpcGVsaW5lQ29weSA9IG51bGw7DQoJSURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxp
bmUuZ2V0Q3Vyc29yKCk7DQoJDQoJdHJ5IHsNCgkJSURhdGFVdGlsLnB1dChjdXJzb3IsICJwaXBl
bGluZURvYyIsIElEYXRhVXRpbC5kZWVwQ2xvbmUocGlwZWxpbmUpKTsNCgl9IGNhdGNoIChFeGNl
cHRpb24gZXgpIHsNCgkJdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRpb24oZXgpOw0KCX0NCgkNCglj
dXJzb3IuZGVzdHJveSgpOw==</value>
</Values>
