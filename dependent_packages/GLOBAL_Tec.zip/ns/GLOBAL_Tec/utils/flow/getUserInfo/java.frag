<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getUserInfo</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNCklEYXRh
VXRpbC5wdXQoIHBpcGVsaW5lQ3Vyc29yLCAidXNlckluZm8iLCBjb20ud20uYXBwLmIyYi5zZXJ2
ZXIuU2VydmljZS5nZXRVc2VyKCkuZ2V0QXNEYXRhKCkpOw0KcGlwZWxpbmVDdXJzb3IuZGVzdHJv
eSgpOw==</value>
</Values>
