<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">waitForServerStartup</value>
  <value name="encodeutf8">true</value>
  <value name="body">U2VydmVyLndhaXRGb3JTdGFydHVwKCk7</value>
</Values>
