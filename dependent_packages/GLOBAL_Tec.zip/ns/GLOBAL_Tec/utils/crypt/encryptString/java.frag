<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">encryptString</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQp0cnkgew0KCUlEYXRh
VXRpbC5wdXQoY3Vyc29yLCAidGVzdCIsIER5bmFtaWNWYXJpYWJsZXNFbmNyeXB0b3IuaW5zdGFu
Y2UoKS5lbmNyeXB0RGF0YSgiSm96a28iKSk7DQp9IGNhdGNoIChEeW5hbWljVmFyaWFibGVzRW5j
cnlwdGlvbkV4Y2VwdGlvbiBlKSB7DQoJLy8gVE9ETyBBdXRvLWdlbmVyYXRlZCBjYXRjaCBibG9j
aw0KCWUucHJpbnRTdGFja1RyYWNlKCk7DQp9DQogDQovL0R5bmFtaWNWYXJpYWJsZXNFbmNyeXB0
b3IuaW5zdGFuY2UoKS5kZWNyeXB0RGF0YShudWxsKQ0KCQ==</value>
</Values>
