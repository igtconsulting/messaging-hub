<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getContextID</value>
  <value name="encodeutf8">true</value>
  <value name="body">Y29tLndtLmFwcC5iMmIuc2VydmVyLkludm9rZVN0YXRlIGlzID0gY29tLndtLmFwcC5iMmIuc2Vy
dmVyLkludm9rZVN0YXRlLmdldEN1cnJlbnRTdGF0ZSgpOwpjb20ud20uYXBwLmF1ZGl0LklBdWRp
dFJ1bnRpbWUgYXIgPSBpcy5nZXRBdWRpdFJ1bnRpbWUoKTsKU3RyaW5nW10gY29udGV4dCA9IGFy
LmdldENvbnRleHRTdGFjaygpOwoKLy8gcGlwZWxpbmUKSURhdGFDdXJzb3IgcGlwZWxpbmVDdXJz
b3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsKSURhdGFVdGlsLnB1dCggcGlwZWxpbmVDdXJzb3Is
ICJjb250ZXh0IiwgY29udGV4dCApOwpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7Cg==</value>
</Values>
