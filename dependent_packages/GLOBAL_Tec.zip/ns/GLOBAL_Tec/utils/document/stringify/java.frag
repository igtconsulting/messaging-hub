<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">stringify</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQoNCg0KT2JqZWN0IG9i
aiA9IElEYXRhVXRpbC5nZXQoIGN1cnNvciwgImRvY3VtZW50IiApOw0KQm9vbGVhbiByZWN1cnNl
ID0gSURhdGFVdGlsLmdldEJvb2xlYW4oY3Vyc29yLCAicmVjdXJzZSIpOw0KDQpvYmogPSB0cmFu
c2Zvcm1JRGF0YSgoSURhdGEpIG9iaiwgcmVjdXJzZSk7DQoNCklEYXRhVXRpbC5wdXQoIGN1cnNv
ciwgInJlc3VsdCIsIG9iaiApOw==</value>
</Values>
