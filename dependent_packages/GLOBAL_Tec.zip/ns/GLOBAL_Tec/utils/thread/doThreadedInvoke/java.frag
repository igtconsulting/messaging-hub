<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">doThreadedInvoke</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGMgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNClN0cmluZyBzZXJ2aWNlID0g
SURhdGFVdGlsLmdldFN0cmluZyhwYywgInNlcnZpY2VOYW1lIik7DQpJRGF0YSBpbnB1dCA9IElE
YXRhVXRpbC5nZXRJRGF0YShwYywgImlucHV0Iik7DQoNCmJvb2xlYW4gaW52b2tlZCA9IHRydWU7
DQp0cnkgew0KCU5TTmFtZSBuc25hbWUgPSBOU05hbWUuY3JlYXRlKHNlcnZpY2UpOw0KCVNlcnZp
Y2UuZG9UaHJlYWRJbnZva2UobnNuYW1lLCBpbnB1dCwgMjAwMCk7DQp9IGNhdGNoIChFeGNlcHRp
b24gZSkgew0KCWludm9rZWQgPSBmYWxzZTsNCn0NCg0KSURhdGFVdGlsLnB1dChwYywgInN0YXR1
cyIsIFN0cmluZy52YWx1ZU9mKGludm9rZWQpKTsNCnBjLmRlc3Ryb3koKTsNCgk=</value>
</Values>
