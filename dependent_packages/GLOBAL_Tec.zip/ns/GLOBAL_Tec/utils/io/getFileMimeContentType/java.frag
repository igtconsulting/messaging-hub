<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getFileMimeContentType</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmcJZmlsZW5hbWUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1
cnNvciwgImZpbGVuYW1lIiApOw0KcGlwZWxpbmVDdXJzb3IuZGVzdHJveSgpOw0KDQpTdHJpbmcg
Y29udGVudFR5cGUgPSBnZXRDb250ZW50VHlwZShmaWxlbmFtZSk7DQoNCi8vIHBpcGVsaW5lDQpJ
RGF0YUN1cnNvciBwaXBlbGluZUN1cnNvcl8xID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQpJRGF0
YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvcl8xLCAiY29udGVudFR5cGUiLCBjb250ZW50VHlwZSAp
Ow0KcGlwZWxpbmVDdXJzb3JfMS5kZXN0cm95KCk7DQoNCgk=</value>
</Values>
