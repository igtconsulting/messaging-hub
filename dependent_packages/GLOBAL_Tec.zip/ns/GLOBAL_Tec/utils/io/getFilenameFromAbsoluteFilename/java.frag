<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getFilenameFromAbsoluteFilename</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ci8vIHBpcGVsaW5lCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7CglTdHJpbmcJZmlsZW5hbWUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1
cnNvciwgImZpbGVuYW1lIiApOwpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7CgpGaWxlIGYgPSBu
ZXcgRmlsZShmaWxlbmFtZSk7ClN0cmluZyByZXN1bHQgPSBmLmdldE5hbWUoKSA7CgovLyBwaXBl
bGluZQpJRGF0YUN1cnNvciBwaXBlbGluZUN1cnNvcl8xID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7
CklEYXRhVXRpbC5wdXQoIHBpcGVsaW5lQ3Vyc29yXzEsICJ2YWx1ZSIsIHJlc3VsdCApOwpwaXBl
bGluZUN1cnNvcl8xLmRlc3Ryb3koKTsK</value>
</Values>
