<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getBytesLength</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQpieXRlW10gYnl0ZXMg
PSAoYnl0ZVtdKSBJRGF0YVV0aWwuZ2V0KGN1cnNvciwgImlucHV0Iik7DQppZiAoYnl0ZXMgPT0g
bnVsbCl7DQoJSURhdGFVdGlsLnB1dCggY3Vyc29yLCAibGVuZ3RoIiwgIjAiKTsNCn0gZWxzZSB7
DQoJSURhdGFVdGlsLnB1dCggY3Vyc29yLCAibGVuZ3RoIiwgU3RyaW5nLnZhbHVlT2YoYnl0ZXMu
bGVuZ3RoKSk7DQp9DQoNCgkNCgk=</value>
</Values>
