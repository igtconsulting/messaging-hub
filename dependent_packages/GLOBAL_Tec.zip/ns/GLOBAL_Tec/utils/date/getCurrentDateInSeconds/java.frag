<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getCurrentDateInSeconds</value>
  <value name="encodeutf8">true</value>
  <value name="body">CQoKSURhdGFDdXJzb3IgcGxjID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7CgpEYXRlIG5vdyA9IG5l
dyBEYXRlKCk7CnRyeSB7CQoJaWYgKHBsYy5maXJzdCgic2Vjb25kcyIpKSBwbGMuZGVsZXRlKCk7
CglwbGMuaW5zZXJ0QWZ0ZXIoInNlY29uZHMiLCAiIiArIG5vdy5nZXRUaW1lKCkvMTAwMCApOwoJ
cGxjLmRlc3Ryb3koKTsKfSBjYXRjaCAoRXhjZXB0aW9uIGUpCgl7fQo=</value>
</Values>
