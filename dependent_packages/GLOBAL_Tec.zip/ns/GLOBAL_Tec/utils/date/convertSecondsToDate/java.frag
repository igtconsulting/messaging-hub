<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">convertSecondsToDate</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required dateFormat</value>
    <value>[i] field:0:required seconds</value>
    <value>[o] field:0:required date</value>
  </array>
  <value name="subtype">unknown</value>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">CglJRGF0YUN1cnNvciBwbGMgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsKCglTdHJpbmcgc3RyU2Vj
b25kcyA9IG51bGw7CglpZiAocGxjLmZpcnN0KCJzZWNvbmRzIikpCgl7CgkJc3RyU2Vjb25kcyA9
IChTdHJpbmcpcGxjLmdldFZhbHVlKCk7Cgl9CgllbHNlCgl7CgkJdGhyb3cgbmV3IFNlcnZpY2VF
eGNlcHRpb24oInNlY29uZHMgbXVzdCBiZSBzdXBwbGllZCEiKTsKCX0gCglTdHJpbmcgc3RyRGF0
ZUZvcm1hdCA9IG51bGw7CglpZiAocGxjLmZpcnN0KCJkYXRlRm9ybWF0IikpCgl7CgkJc3RyRGF0
ZUZvcm1hdCA9IChTdHJpbmcpcGxjLmdldFZhbHVlKCk7Cgl9CgllbHNlCgl7CgkJdGhyb3cgbmV3
IFNlcnZpY2VFeGNlcHRpb24oImRhdGVGb3JtYXQgbXVzdCBiZSBzdXBwbGllZCEiKTsKCX0KCQoJ
bG9uZyBzZWNvbmRzID0gTG9uZy5wYXJzZUxvbmcoc3RyU2Vjb25kcykqMTAwMDsKCURhdGUgZmRh
dGUgPSBuZXcgRGF0ZShzZWNvbmRzKTsKCglTaW1wbGVEYXRlRm9ybWF0IHNkZiA9IG5ldyBTaW1w
bGVEYXRlRm9ybWF0KHN0ckRhdGVGb3JtYXQpOwoJU3RyaW5nIHN0ckRhdGUgPSBzZGYuZm9ybWF0
KGZkYXRlKTsKCglpZiAocGxjLmZpcnN0KCJkYXRlIikpIHBsYy5kZWxldGUoKTsKCXBsYy5pbnNl
cnRBZnRlcigiZGF0ZSIsICIiICsgc3RyRGF0ZSApOwoJcGxjLmRlc3Ryb3koKTsgCiAK</value>
</Values>
