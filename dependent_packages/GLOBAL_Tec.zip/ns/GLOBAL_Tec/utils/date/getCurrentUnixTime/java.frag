<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getCurrentUnixTime</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNCklEYXRh
VXRpbC5wdXQoIHBpcGVsaW5lQ3Vyc29yLCAiZXBvY2giLCBTdHJpbmcudmFsdWVPZihTeXN0ZW0u
Y3VycmVudFRpbWVNaWxsaXMoKS8xMDAwKSk7DQoJ</value>
</Values>
